<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard - SafeVoice</title>
  <link rel="stylesheet" href="dashboard.css">
</head>
<body>
  <main class="main-content">
  <div class="container">
    <div class="box">
      <h2 class="title">Data Diri</h2>
      <form method="POST" action="proses_akun.php">
        <a>Nama <?php echo $_SESSION['username']; ?> !</a>

        <label>Jurusan</label>
        <input type="text" name="jurusan" placeholder="Jurusan" required>

        <label>Fakultas</label>
        <input type="text" name="fakultas" placeholder="fakultas" required>

        <label>Angkatan</label>
        <input type="text" name="angkatan" placeholder="angkatan" required>

        <label>Tanggal Lahir</label>
        <input type="text" name="tanggal_lahir" placeholder="tanggal_lahir" required>

        <button type="submit" class="button">Simpan</button>
      </form>
      <p class="login-text"><a href="login.php">Logout</a></p>
    </div>
  </div>

  <div class="sidebar">
  <h2>SafeVoice</h2>
  <ul>
    <li><a href="dashboard.php"><i class="icon">🏠</i> Dashboard</a></li>
    <li><a href="forum.php"><i class="icon">💬</i> Forum Diskusi</a></li>
    <li><a href="pengaturan.php"><i class="icon">⚙️</i> Pengaturan</a></li>
    <li><a href="dashboard.php"><i class="icon">🚪</i> Keluar</a></li>
   </ul>
   </div>

  <footer class="footer">
    <p>© 2025 SafeVoice. Semua Hak Dilindungi.</p>
  </footer>
</body>
</html>
