<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard - SafeVoice</title>
  <link rel="stylesheet" href="dashboard.css">
</head>
<body>
  <header class="header">
    <h1>Selamat Datang, Admin <?php echo $_SESSION['username']; ?> !</h1>
    <a href="login.php" class="logout-button">Logout</a>
  </header>

  <main class="main-content">
    <section class="card">
      <h2>Laporan Masuk</h2>
      <a href="laporan_admin.php" class="button">Cek Laporan Masuk</a>
    </section>

    <section class="card">
      <h2>Artikel</h2>
      <a href="artikel_admin.php" class="button">List Artikel</a>
    </section>
  </main>

  <div class="sidebar">
  <h2>SafeVoice</h2>
  <ul>
    <li><a href="dashboard_admin.php"><i class="icon">🏠</i> Dashboard</a></li>
    <li><a href="C:\xampp\htdocs\RPL\forum\forum_admin.php"><i class="icon">💬</i> Forum Diskusi</a></li>
    <li><a href="pengaturan.php"><i class="icon">⚙️</i> Pengaturan</a></li>
    <li><a href="dashboard.php"><i class="icon">🚪</i> Keluar</a></li>
   </ul>
   </div>

  <footer class="footer">
    <p>© 2025 SafeVoice. Semua Hak Dilindungi.</p>
  </footer>
</body>
</html>
